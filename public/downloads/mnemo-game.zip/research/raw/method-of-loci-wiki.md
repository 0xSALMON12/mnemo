# Method of loci
URL: https://en.wikipedia.org/wiki/Method_of_loci
Published: 2005-04-02T22:47:58Z

Method of loci - Wikipedia

- 

- 

- 
- 
- 
- 
- 
- 
- 
- 
- 
- 
- 
- 

Jump to content

	

	
 
 

 

 
 
 
 
 

	

	
 
 

 

 
 
 
 
 
 
 
 

 
 

 
 

 

 

 
 
 
 
 

 

 
 
 
 

 From Wikipedia, the free encyclopedia

 

 
 

 
 Memory techniques adopted in ancient Roman and Greek rhetorical treatises
- - 
This article is about the memorization method. For other uses, see Locus.

- "Memory palace" redirects here. For the podcast, see The Memory Palace. For other uses, see Memory palace (disambiguation).

Part of a series on
Rhetoric

showHistory

- Ancient India

- Ancient Greece
- Asianism

- Atticism

- Attic orators

- Calliope

- Classical rhetoric

- Sophists

- Ancient Rome
- The age of Cicero

- Second Sophistic

- Middle Ages
- Byzantine rhetoric

- Trivium

- Renaissance
- Studia humanitatis

- Modern period

showConcepts

- Captatio benevolentiae

- Chironomia

- Decorum

- Delectare

- Docere

- Device

- Eloquence
- Eloquentia perfecta

- Eunoia

- Enthymeme

- Facilitas

- Fallacy
- Informal

- Figure of speech
- Scheme

- Trope

- Five canons
- Inventio

- Dispositio

- Elocutio

- Memoria

- Pronuntiatio

- Hypsos

- Imitatio

- Kairos

- Method of loci

- Modes

- Operations

- Persuasion
- Ethos

- Pathos

- Logos

- Situation

- Style
- Grand

- Sotto voce

- Topos

showGenres

- Apologetics

- Debate

- Declamation
- Controversia

- Deliberative

- Demagogy

- Dialectic
- Socratic method

- Dissoi logoi

- Elocution

- Epideictic
- Encomium

- Panegyric

- Eulogy

- Farewell speech

- Forensic

- Funeral oration

- Homiletics‎
- Sermon

- Invitational

- Lecture
- Public

- Lightning talk

- Maiden speech

- Oratory

- Polemic
- Diatribe

- Eristic

- Philippic

- Progymnasmata
- Suasoria

- Propaganda
- Spin

- Resignation speech

- Stump speech

- War-mongering

showCriticism

- Cluster

- Dramatic
- Pentadic

- Frame

- Genre

- Ideological

- Metaphoric

- Mimesis

- Narrative

- Neo-Aristotelian

showRhetoricians

- Aeschines

- Aelius Aristides

- Antiphon

- Aristotle

- Aspasia

- Augustine

- Bakhtin

- Booth

- Brueggemann

- Burke

- Cicero

- de Man

- Demosthenes

- Derrida

- Dio Chrysostom

- Erasmus

- Gorgias

- Hobbes

- Hypereides

- Isocrates

- Lucian

- Lysias

- McLuhan

- Ong

- Perelman

- Pizan

- Protagoras

- Quintilian

- Ramus

- Richards

- Seneca the Elder

- Smith

- Toulmin

- Vico

- Weaver

showWorks

- Gorgias (380 BC)

- Phaedrus (c. 370 BC)

- Rhetoric (c. 350 BC)

- Rhetoric to Alexander (c. 350 BC)

- De Sophisticis Elenchis (c. 350 BC)

- Topics (c. 350 BC)

- De Inventione (84 BC)

- Rhetorica ad Herennium (80 BC)

- De Oratore (55 BC)

- A Dialogue Concerning Oratorical Partitions (c. 50 BC)

- De Optimo Genere Oratorum (46 BC)

- Orator (46 BC)

- On the Sublime (c. 50)

- Institutio Oratoria (95)

- Panegyrici Latini (100–400)

- Dialogus de oratoribus (102)

- De doctrina Christiana (426)

- De vulgari eloquentia (1305)

- Copia: Foundations of the Abundant Style (1521)

- Language as Symbolic Action (1966)

- A General Rhetoric (1970)

showSubfields

- Argumentation

- Cognitive

- Contrastive

- Constitutive

- Digital

- Feminist

- Native American

- New

- Health and medicine

- Pedagogy

- Procedural

- Science

- Technology

- Therapy

- Visual
- Composition

showRelated

- Ars dictaminis

- Communication studies

- Composition studies

- Doxa

- Glossary of rhetorical terms

- Glossophobia

- List of feminist rhetoricians

- List of speeches

- Oral skills

- Orator

- Pistis

- Public rhetoric

- Rhetoric of social intervention model

- Rhetrickery

- Rogerian argument

- Seduction

- Speechwriting

- Talking point

- TED

- Terministic screen

- Toulmin model

- Wooden iron

- - v
- t
- e

The method of loci is a mnemonic technique that uses visual imagination and spatial memory to organize and recall information. It involves mentally associating pieces of information with specific locations in a familiar environment, such as rooms in a house or landmarks along a well-known route. The user visualizes these locations in sequence and imagines placing the items to be remembered at each point. Recall is achieved by mentally retracing the path and using the imagined scenes to retrieve the associated information.

This method is also referred as the memory palace, memory journey, journey method or mind palace technique.

## History
[edit]

## Classical Roman accounts
[edit]

The method of loci is traditionally associated with the Greek poet Simonides of Ceos, who is said to have used it to recall the seating arrangement at a banquet hall that collapsed, allowing him to identify the crushed victims by remembering where each person had been seated. The story appears in Cicero's De Oratore (55 BCE) and was later recounted by Quintilian in Institutio Oratoria (circa 95 CE). A detailed description of the technique also appears in the anonymous Rhetorica ad Herennium (circa 90 BCE).[1][2][3]

## Renaissance
[edit]

The method of loci experienced a significant revival during the Renaissance, notably through the work of Matteo Ricci, a 16th-century Italian missionary. Ricci adapted the technique to help memorize Chinese characters, Confucian texts, and Christian teachings while carrying out his missionary activities in China. This adaptation allowed him to effectively interact with Chinese scholars. In 1596, he published a treatise titled, meaning A Treatise on Mnemonics, written in Chinese. This work introduced the method of loci to East Asian audiences as a means of intellectual development.[4][5]

Another prominent figure of the Renaissance, Giordano Bruno, further developed the method by incorporating esoteric elements. In his 1582 work De umbris idearum (On the Shadows of Ideas), Bruno combined the method of loci with Hermetic philosophy and elaborate astrological symbols to construct complex memory theaters designed for storing philosophical and symbolic knowledge. His approach emphasized dynamic and symbolic locations to represent expansive cosmological frameworks, which influenced subsequent esoteric thought and memory practices.[6]- - [better source needed]

## 20th century
[edit]

In the 20th century, the method of loci gained broader recognition through both popular and scholarly works. Harry Lorayne introduced the technique to a general audience in books such as How to Develop a Super-power Memory (1957), presenting it alongside other mnemonic systems for everyday use. Historian Frances A. Yates contributed to its academic revival with The Art of Memory (1966), a study tracing the historical development of the method and helping to renew scholarly interest in the subject.[7][8]

## Method
[edit]

The method of loci is a memory technique that uses familiar spaces such as a house, building, or route to help remember information.[9] For example, items from a shopping list might be mentally linked to different areas of a home: a loaf of bread on the front step, a bottle of orange juice spilled in the entryway, or apples hanging from a light fixture in the living room. The images used are often vivid or unusual, which helps them stand out in memory.

The sequence of locations provides a structured way to store information. When someone needs to remember the content, they retrieve it by moving through the locations in their imagination, one after another. Because the layout of the space is already well known, it acts as a reliable framework for finding each associated item.

## Uses
[edit]

The method of loci is employed by many participants in memory competitions, including events such as the World Memory Championship.[10] They use it to memorize items such as shuffled decks of cards, long strings of numbers, and lists of words.

Some students also apply this technique to remember historical dates, vocabulary, and key concepts for exams.[11]

Beyond academic and competitive settings, the method is also useful in daily life, helping individuals remember everyday tasks such as shopping lists.[12]

Because of its flexibility, the method of loci is taught in many learning-to-learn courses as a metacognitive strategy, encouraging learners to become more aware of their own thinking and memory processes.[13]

## Notable practitioners
[edit]

Several notable practitioners have used the method of loci. 

Dominic O'Brien, an eight-time World Memory Champion, has contributed to the popularization of the technique through his instructional writings and training programs. He developed the Dominic System, which he regularly uses to remember information. In his 1993 book How to Develop a Perfect Memory, O'Brien explains how to apply the method of loci in both everyday contexts and memory competitions. Through workshops and his Peak Performance Training program, he has taught these techniques to several individuals.[14][15][16]

Joshua Foer is a journalist and the 2006 U.S. Memory Champion. He is the author of Moonwalking with Einstein: The Art and Science of Remembering Everything, published in 2011. In the book, he recounts his training for memory competitions, shares insights from his experiences, and explains various memory techniques. Among the methods he employs are the method of loci, which he often combines with other systems such as the Major System and the Person-Action-Object system.[17][18][19]

Timur Gareyev, a chess grandmaster from Uzbekistan, played blindfold chess in a simultaneous exhibition against 48 opponents at the same time. In blindfold chess, players do not see the boards and must keep track of all moves in their mind. Gareyev said he adapted the method of loci to help remember the positions.[20][21]

## Fictional portrayals
[edit]

- Fictional portrayals of the method of loci extend as far back as ancient Greek myths.- - [which?]- - [citation needed]

- In the novels Hannibal (1999) and Hannibal Rising (2006), by Thomas Harris, a detailed description of Hannibal Lecter's memory palace is provided.[22][23]

We catch up to him as the swift slippers of his mind pass from the foyer into the Great Hall of the Seasons. The palace is built according to the rules discovered by Simonides of Ceos and elaborated by Cicero four hundred years later; it is airy, high-ceilinged, furnished with objects and tableaux that are vivid, striking, sometimes shocking and absurd, and often beautiful. The displays are well spaced and well lighted like those of a great museum. [...] On the floor before the painting is this tableau, life-sized in painted marble. A parade in Arlington National Cemetery led by Jesus, thirty-three, driving a '27 Model-T Ford truck, a "Tin Lizzie", with J. Edgar Hoover standing in the truck bed wearing a tutu and waving to an unseen crowd. Marching behind him is Clarice Starling carrying a .308 Enfield rifle at shoulder arms.

- In the first episode of Bordertown (2016), detective Kari Sorjonen explains the memory palace concept, and, throughout the series, he marks rectangles with tape on his basement floor where he stands to imagine himself at various significant loci in a case, organized into memory palaces.[24]

- The television series The Mentalist, which premiered in late 2008, mentions memory palaces on multiple occasions. The main character Patrick Jane claims to use a memory palace to memorise cards and gamble successfully. In the eleventh episode of season two, Jane teaches his colleague Wayne Rigsby how to construct a memory palace, explaining that they are good for memorising large chunks of information at a time.

- In "The Reunion Job", Episode 2 of Season 3 of the television show Leverage, the criminal team must "hack" the Roman Room of a tech giant, as he's created a memory palace out of his senior year in high school to remember his passwords.

- In the 2003 film Dreamcatcher, the character Jonesy has an elaborate memory palace which plays a major role in the plot and is shown several times in the film, depicted as a physical building that Jonesy is walking through as a way to represent him accessing the memories.

- In the BBC television series Sherlock, which premiered in 2010, the title character uses mind palaces to remember various things throughout the show.

- In Hilary Mantel's 2009 novel Wolf Hall, the fictionalized version of Thomas Cromwell describes "memory palace" techniques and his uses of it.[25]

- In the 2017 medical drama The Good Doctor, series protagonist Shaun Murphy uses the Method of Loci to figure out various medical diagnoses.

- In the 2020 video game The Sinking City, the main character Charles Reed is a detective that keeps points of interest in a mind palace menu.

- In the 2020 video game Twin Mirror, the main character Sam Higgs uses the mind palace in various points of the game to relive memories and investigate.

- In the 2023 video game Alan Wake II, FBI Agent Saga Anderson uses an adapted version, which she calls the "Mind Place," throughout the story to review cases and associated evidence.

## See also
[edit]

- Catherine of Siena's "inner cell"

- Memory lane

- Mental image

- Spatial memory

## Citations
[edit]

- ↑ Cicero, Marcus Tullius; Watson, John S.; Micken, Ralph A.; Cicero, Marcus Tullius (1986). Cicero on oratory and orators. Landmarks in rhetoric and public address (Nachdr. der Ausg. New York, 1878 ed.). Carbondale: Southern Illinois Univ. Press. ISBN 978-0-8093-1293-1.

- ↑ - Quintilianus, Marcus Fabius (1985), The Institutio oratoria of Quintilian. 2: Books IV -VI, The Loeb classical library (Repr ed.), London: Heinemann, ISBN 978-0-434-99125-9

- ↑ - Cicero, Marcus Tullius; Caplan, Harry; Cicero, Marcus Tullius (2004), Cicero: in twenty-eight volumes. 1: Rhetorica ad Herennium / with an English translation by Harry Caplan, The Loeb classical library (Reprinted ed.), Cambridge, Mass.: Harvard Univ. Press, ISBN 978-0-674-99444-7

- ↑ - Zhao, Ming (2024). Matteo Ricci and the missionary role in the evolution of Chinese lexicon. Interdisciplinary and transcultural approaches to Chinese literature. Abingdon, Oxon New York, NY: Routledge =978-1-032-78996-5. p. 70.

- ↑ - Jaewon Ahn (December 2017). "On () of Matteo Ricci (1552-1610)". The Journal of Greco-Roman Studies. 56 (3): 99–121. doi:10.23933/jgrs.2017.56.3.99. ISSN 1225-1828.

- ↑ - Bruno, Giordano; Gosnell, Scott (2013). De Umbris Idearum: On the Shadows of Ideas (Collected Works of Giordano Bruno). CreateSpace Independent Publishing Platform. ISBN 9781492329961.

- ↑ - Lorayne, Harry (1957). How to Develop a Super-power Memory (Hardbook). New York: Fell Publishers.

- ↑ - Yates, Frances A. (1966). The art of memory (Hardcover). Chicago (Ill.): University of Chicago press.

- ↑ - "How to build a memory palace to store and revisit information | Psyche Guides". psyche.co. Retrieved 2026-01-09.

- ↑ - Frisch, Ian (2016-05-18). "Lessons from America's First Memory World Champion". The New Yorker. ISSN 0028-792X. Retrieved 2026-01-23.

- ↑ - "An Ancient and Proven Way to Improve Memorization; Go Ahead and Try It (Published 2016)". 2016-03-24. Archived from the original on 2025-09-15. Retrieved 2026-01-23.

- ↑ - "How to Improve Your Memory". HowStuffWorks. 2007-05-17. Retrieved 2026-01-23.

- ↑ - "Learning How to Learn: Powerful mental tools to help you master tough subjects - Coursera". Coursera.

- ↑ - O'Brien, Dominic (1993). How to develop a perfect memory. London: Pavilion. ISBN 978-1-85793-106-8.

- ↑ - "How a memory champ's brain works". 2009-04-07. Retrieved 2026-01-23.

- ↑ - "Memory Training". Dominic O'Brien. Retrieved 2026-01-23.

- ↑ - Foer, Joshua (2011). Moonwalking with Einstein: The Art and Science of Remembering Everything. Penguin Publishing Group. ISBN 9780141952277.

- ↑ - Nast, Condé. "This Guy Can Teach You How to Memorize Anything". WIRED. Retrieved 2026-01-23.

- ↑ - Foer, Joshua. "How I Became a Master of Memory". Discover Magazine. Retrieved 2026-01-23.

- ↑ - "Memory Palace - Timur's World Record preparation - ChessBase India". www.chessbase.in. 2016-12-03. Retrieved 2026-01-23.

- ↑ - Doggers (PeterDoggers), Peter (2016-12-05). "Timur Gareyev Plays Record 48 Games Blindfolded - Now Recognized By Guinness". Chess.com. Retrieved 2026-01-23.

- ↑ - Harris, Thomas (2006). Hannibal Rising. United States: Delacorte Press. pp. 1–2, 167, 178–179. ISBN 978-0385339414.

- ↑ - Martinez-Conde, Susana (April 26, 2013). "Neuroscience in Fiction: Hannibal Lecter's Memory Palace". Scientific American.

- ↑ - "Recent Nordic Noir in Print and Television, Part Two: Finland". Critics at Large. Retrieved 27 March 2022.

- ↑ - "Wolf Hall and the memory palace". Nathan Carterette. 6 June 2014. Retrieved 2020-10-24.

## General and cited references
[edit]

- - Bolzoni, Lina (2001). The Gallery of Memory. University of Toronto Press. ISBN 978-0802043306.

- - Bolzoni, Lina (2004). The Web of Images. Ashgate Publishers. ISBN 978-0754605515.

- - Brown, Derren (2007). Tricks of the Mind. London: Transworld publishers.

- - Carruthers, Mary; Ziolkowski, Jan (2002). The Medieval Craft of Memory: An anthology of texts and pictures. University of Pennsylvania Press. ISBN 978-0812218817.

- - Carruthers, Mary (1990). The Book of Memory. Cambridge University Press. ISBN 978-0521716314.

- - Carruthers, Mary (1998). The Craft of Thought. Cambridge University Press. ISBN 978-0521795418.

- Dann, Jack (1995) The Memory Cathedral: A Secret History of Leonardo da Vinci: Bantam Books 0553378570

- Dresler, Martin, et al."Mnemonic Training Reshapes Brain Networks to Support Superior Memory", Neuron, 8 March 2017.

- - Dudai, Yadin (2002). Memory from A to Z. Oxford University Press. ISBN 978-0198520870.

- - Foer, Joshua (2011). Moonwalking with Einstein: The Art and Science of Remembering Everything. New York: Penguin Press. ISBN 978-1-59420-229-2.

- - Lyndon, Donlyn; Moore, Charles W. (1994). Chambers for a Memory Palace. Cambridge, Massachusetts: The MIT Press. ISBN 9780262621052.

- - Rossi, Paolo (2000). Logic and the Art of Memory. University of Chicago Press. ISBN 978-0226728261.

- - Small, Jocelyn P. (1997). Wax Tablets of the Mind. London: Routledge. ISBN 978-0415149839.

- - Spence, Jonathan D. (1984). The Memory Palace of Matteo Ricci. New York: Viking Penguin. ISBN 978-0-14-008098-8.

- - Yates, Frances A. (1966). The Art of Memory. Chicago: University of Chicago Press. ISBN 978-0226950013.

- 
- 
- 
- 
- 
- 
- 

Retrieved from "https://en.wikipedia.org/w/index.php?title=Method_of_loci&oldid=1376634308"

 Categories: - Cognitive training
- Conceptual models
- Dialectic
- Learning methods
- Mnemonics
- Rhetoric
- Spatial cognition

Hidden categories: - Articles with short description
- Short description is different from Wikidata
- All articles lacking reliable references
- Articles lacking reliable references from January 2026
- All articles with specifically marked weasel-worded phrases
- Articles with specifically marked weasel-worded phrases from November 2024
- All articles with unsourced statements
- Articles with unsourced statements from November 2024

 

 
 
 

 
 
 

	
 

 

	
 
 
 

Search
 
 

 
 
 
 
 
 
 
 
 
 

 
 

 Search
 
 

 

 

 
 
 Method of loci

 

 

 
 
 

 
 

 
 

 
 

 
 

 
 

 
 

 
 

 
 

32 languages
 
 

Add topic
